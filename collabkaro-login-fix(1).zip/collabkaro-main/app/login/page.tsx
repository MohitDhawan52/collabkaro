'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Eye, EyeOff, ArrowRight, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { createClient } from '@/lib/supabase'

export default function LoginPage() {
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading]   = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email || !password) { toast.error('Please fill in both fields'); return }
    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) {
      setLoading(false)
      toast.error(error.message === 'Invalid login credentials' ? 'Incorrect email or password' : error.message)
      return
    }
    const { data: { user } } = await supabase.auth.getUser()
    const { data: profile }  = await supabase.from('profiles').select('role, status').eq('id', user!.id).single()
    toast.success('Welcome back!')
    if (!profile)                        { window.location.href = '/' }
    else if (profile.status === 'pending')  { window.location.href = profile.role === 'brand' ? '/brand/pending' : '/influencer/pending' }
    else if (profile.status === 'rejected') { window.location.href = '/rejected' }
    else if (profile.role === 'brand')      { window.location.href = '/brand/dashboard' }
    else if (profile.role === 'influencer') { window.location.href = '/influencer/dashboard' }
    else                                    { window.location.href = '/' }
  }

  return (
    <div className="auth-page">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className="w-full"
        style={{ maxWidth: 440 }}
      >

        {/* ── Card ── */}
        <div className="auth-card" style={{ padding: '48px 44px 40px' }}>

          {/* Header — logo + title + subtitle */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            textAlign: 'center',
            marginBottom: 40,
            gap: 0,
          }}>
            <div className="icon-badge" style={{ marginBottom: 20 }}>
              <span className="font-display" style={{
                fontSize: 24,
                fontWeight: 800,
                color: '#fff',
                lineHeight: 1,
                letterSpacing: '-0.02em',
              }}>C</span>
            </div>

            <h1 className="font-display" style={{
              fontSize: 26,
              fontWeight: 800,
              color: 'var(--text-primary)',
              letterSpacing: '-0.03em',
              lineHeight: 1.15,
              marginBottom: 10,
            }}>
              CollabKaro
            </h1>

            <p style={{
              fontSize: 14.5,
              color: 'var(--text-muted)',
              lineHeight: 1.5,
              maxWidth: 260,
            }}>
              Sign in to manage your collaborations
            </p>
          </div>

          {/* ── Form ── */}
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

            {/* Email field */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <label className="field-label">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
                className="input"
                disabled={loading}
              />
            </div>

            {/* Password field */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <label className="field-label">Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••"
                  autoComplete="current-password"
                  className="input"
                  style={{ paddingRight: 48 }}
                  disabled={loading}
                />
                {/* Eye toggle — properly centered */}
                <button
                  type="button"
                  onClick={() => setShowPassword(v => !v)}
                  tabIndex={-1}
                  style={{
                    position: 'absolute',
                    right: 0,
                    top: 0,
                    bottom: 0,
                    width: 48,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    color: 'var(--text-muted)',
                    borderRadius: '0 12px 12px 0',
                    transition: 'color 0.15s ease',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'var(--brand-primary)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
                >
                  {showPassword ? <EyeOff size={16} strokeWidth={1.8} /> : <Eye size={16} strokeWidth={1.8} />}
                </button>
              </div>
            </div>

            {/* Submit button */}
            <div style={{ marginTop: 4 }}>
              <button
                type="submit"
                disabled={loading}
                className="btn btn-primary"
                style={{ width: '100%', fontSize: 15, padding: '14px 24px', borderRadius: 14 }}
              >
                {loading ? (
                  <>
                    <Loader2 size={16} strokeWidth={2} className="animate-spin" />
                    <span>Signing in…</span>
                  </>
                ) : (
                  <>
                    <span>Sign in</span>
                    <ArrowRight size={16} strokeWidth={2} />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* ── Divider ── */}
          <div style={{
            margin: '28px 0 24px',
            borderTop: '1px solid var(--border-default)',
          }} />

          {/* Sign up link */}
          <p style={{
            textAlign: 'center',
            fontSize: 14,
            color: 'var(--text-muted)',
            lineHeight: 1.5,
          }}>
            New to CollabKaro?{' '}
            <Link
              href="/register"
              style={{
                color: 'var(--brand-primary)',
                fontWeight: 600,
                textDecoration: 'none',
              }}
            >
              Create an account
            </Link>
          </p>
        </div>

        {/* Below-card footnote */}
        <p style={{
          textAlign: 'center',
          fontSize: 12.5,
          color: 'var(--text-muted)',
          marginTop: 24,
          lineHeight: 1.5,
          opacity: 0.8,
        }}>
          Trusted by 500+ brands &amp; influencers across India
        </p>

      </motion.div>
    </div>
  )
}
