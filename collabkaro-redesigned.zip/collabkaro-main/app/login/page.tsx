'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Eye, EyeOff, ArrowRight, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { createClient } from '@/lib/supabase'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email || !password) { toast.error('Please fill in both fields'); return }
    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) {
      setLoading(false)
      toast.error(error.message === 'Invalid login credentials' ? 'Incorrect email or password' : error.message)
      return
    }
    const { data: { user } } = await supabase.auth.getUser()
    const { data: profile } = await supabase.from('profiles').select('role, status').eq('id', user!.id).single()
    toast.success('Welcome back!')
    if (!profile) { window.location.href = '/' }
    else if (profile.status === 'pending') { window.location.href = profile.role === 'brand' ? '/brand/pending' : '/influencer/pending' }
    else if (profile.status === 'rejected') { window.location.href = '/rejected' }
    else if (profile.role === 'brand') { window.location.href = '/brand/dashboard' }
    else if (profile.role === 'influencer') { window.location.href = '/influencer/dashboard' }
    else { window.location.href = '/' }
  }

  return (
    <div className="auth-page">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="w-full max-w-[420px]"
      >
        <div className="auth-card p-10 sm:p-12">
          {/* Badge + title block, centered like MonkWise */}
          <div className="flex flex-col items-center text-center mb-9">
            <div className="icon-badge mb-5">
              <span className="font-display text-2xl font-bold text-white">C</span>
            </div>
            <h1 className="font-display text-2xl font-bold mb-1.5" style={{ color: 'var(--text-primary)' }}>
              CollabKaro
            </h1>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
              Sign in to manage your collaborations
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <label className="field-label">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
                className="input"
                disabled={loading}
              />
            </div>

            <div className="space-y-1.5">
              <label className="field-label">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••"
                  autoComplete="current-password"
                  className="input"
                  style={{ paddingRight: '44px' }}
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(v => !v)}
                  className="absolute right-4 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-muted)' }}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button type="submit" disabled={loading} className="btn btn-primary w-full">
                {loading
                  ? <><Loader2 size={15} className="animate-spin" /> Signing in...</>
                  : <>Sign in <ArrowRight size={15} /></>
                }
              </button>
            </div>
          </form>

          <p className="text-center text-sm mt-7" style={{ color: 'var(--text-muted)' }}>
            New to CollabKaro?{' '}
            <Link href="/register" className="font-semibold" style={{ color: 'var(--brand-primary)' }}>
              Create an account
            </Link>
          </p>
        </div>

        <p className="text-center text-xs mt-6" style={{ color: 'var(--text-muted)' }}>
          Trusted by 500+ brands & influencers across India
        </p>
      </motion.div>
    </div>
  )
}